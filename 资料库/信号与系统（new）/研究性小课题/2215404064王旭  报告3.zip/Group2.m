I = imread('Group2.png'); 
F = fft2(I);
F_magnitude = abs(F/256); 
subplot(1, 2, 1);
imshow(uint8(I)), title('Original');
subplot(1, 2, 2);
imshow(F_magnitude), title('DFT');